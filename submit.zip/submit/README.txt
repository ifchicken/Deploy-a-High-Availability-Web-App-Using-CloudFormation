URL:
http://webapplb-386032218.us-west-2.elb.amazonaws.com/